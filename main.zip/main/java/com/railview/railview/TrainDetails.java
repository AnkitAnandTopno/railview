package com.railview.railview;

public class TrainDetails {
    private String _train_no, _train_name, _start_date;
    public TrainDetails(String _train_no, String _train_name, String _start_date){
        this._train_no = _train_no;
        this._train_name = _train_name;
        this._start_date = _start_date;
    }

    public String get_train_no() {
        return _train_no;
    }

    public void set_train_no(String _train_no) {
        this._train_no = _train_no;
    }

    public String get_train_name() {
        return _train_name;
    }

    public void set_train_name(String _train_name) {
        this._train_name = _train_name;
    }

    public String get_start_date() {
        return _start_date;
    }

    public void set_start_date(String _start_date) {
        this._start_date = _start_date;
    }
}
