package com.railview.railview;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.HashMap;

public class DatabaseHandler extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "RailView.db";
    public static final String TABLE_NAME = "pnr_details", TABLE_NAME1 = "train_details";

    public DatabaseHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " (id INTEGER PRIMARY KEY AUTOINCREMENT" +
                ", pnr_no TEXT" +
                ", train_no TEXT" +
                ", boarding_point TEXT" +
                ", date TEXT);";
        db.execSQL(query);
        String query1 = "CREATE TABLE " + TABLE_NAME1 + " (id INTEGER PRIMARY KEY AUTOINCREMENT" +
                ", train_no TEXT" +
                ", train_name TEXT" +
                ", start_date TEXT);";
        db.execSQL(query1);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME + ";");
        onCreate(db);
    }

    //Adding user Credentials
    public void addUser(PnrDetails pnrDetails) {
        ContentValues values = new ContentValues();
        values.put("pnr_no", pnrDetails.get_pnr_no());
        values.put("train_no", pnrDetails.get_train_no());
        values.put("boarding_point", pnrDetails.get_boarding_point());
        values.put("date", pnrDetails.get_date());
        SQLiteDatabase db = getWritableDatabase();
        db.insert(TABLE_NAME, null, values);
        db.close();
    }
    //Adding user Credentials
    public void addTrain(TrainDetails trainDetails) {
        ContentValues values = new ContentValues();
        values.put("train_no", trainDetails.get_train_no());
        values.put("train_name", trainDetails.get_train_name());
        values.put("start_date", trainDetails.get_start_date());
        SQLiteDatabase db = getWritableDatabase();
        db.insert(TABLE_NAME1, null, values);
        db.close();
    }

    //Deleting user Credentials
    public void deleteUser() {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_NAME);
        db.execSQL("DELETE FROM " + TABLE_NAME1);
    }

    //Fetching user Credentials
    public Tobject fetchUser() {
        String pnr_number, train_number, date, boarding_point;
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + " ;";

        Cursor c = db.rawQuery(query, null);

        if (c.getCount() > 0) {
            c.moveToFirst();

            pnr_number = c.getString(c.getColumnIndex("pnr_no"));
            train_number = c.getString(c.getColumnIndex("train_no"));
            date = c.getString(c.getColumnIndex("date"));
            boarding_point = c.getString(c.getColumnIndex("boarding_point"));

            Tobject tobject = new Tobject();
            tobject.pnr_number = pnr_number;
            tobject.train_number = train_number;
            tobject.date = date;
            tobject.boarding_point = boarding_point;
            tobject.isUserCredThere = true;
            c.close();
            return tobject;
        } else {
            Tobject tobject = new Tobject();

            tobject.pnr_number = "";
            tobject.train_number = "";
            tobject.date = "";
            tobject.isUserCredThere = false;
            c.close();
            return tobject;
        }
    }
    //FETCH TRAIN DETAILS
    public TrainObject fetchTrain() {
        String train_number, train_name, start_date;
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME1 + " ;";

        Cursor c = db.rawQuery(query, null);

        if (c.getCount() > 0) {
            c.moveToFirst();

            train_number = c.getString(c.getColumnIndex("pnr_number"));
            train_name = c.getString(c.getColumnIndex("train_number"));
            start_date = c.getString(c.getColumnIndex("date"));

            TrainObject trainobject = new TrainObject();
            trainobject.train_name = train_name;
            trainobject.train_no = train_number;
            trainobject.start_date = start_date;
            c.close();
            return trainobject;
        } else {
            TrainObject trainobject = new TrainObject();
            trainobject.train_name = "";
            trainobject.train_no = "";
            trainobject.start_date = "";
            c.close();
            return trainobject;
        }
    }
}
class Tobject{
    String pnr_number,train_number,date,boarding_point;
    boolean isUserCredThere;
}
class TrainObject{
    String train_no, train_name, start_date;
}
