package com.railview.railview;

public class PnrDetails {
    private String _pnr_no,_train_no,_date, _boarding_point;
    public PnrDetails(String _pnr_no, String _train_no, String _date, String _boarding_point){
        this._pnr_no = _pnr_no;
        this._train_no = _train_no;
        this._date = _date;
        this._boarding_point = _boarding_point;
    }

    public String get_boarding_point() {
        return _boarding_point;
    }

    public void set_boarding_point(String _boarding_point) {
        this._boarding_point = _boarding_point;
    }

    public String get_date() {
        return _date;
    }

    public void set_date(String _date) {
        this._date = _date;
    }

    public String get_pnr_no() {
        return _pnr_no;
    }

    public void set_pnr_no(String _pnr_no) {
        this._pnr_no = _pnr_no;
    }

    public String get_train_no() {
        return _train_no;
    }

    public void set_train_no(String _train_no) {
        this._train_no = _train_no;
    }
}
