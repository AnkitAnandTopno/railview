package com.railview.railview;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Timer;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private DatabaseHandler databaseHandler;
    private View loader;
    private View initialize;
    private TextView sender;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //LOADER AND INITIALIZER INITIALIZE
        loader = findViewById(R.id.loader);
        initialize = findViewById(R.id.gettingStarted);
        //DB INITIALIZE
        databaseHandler = new DatabaseHandler(this, null, null, 1);
        sender = findViewById(R.id.sender);
        String senderText = sender.getText().toString()+"\nLOB";
        sender.setText(senderText);

        if(databaseHandler.fetchUser().isUserCredThere){
            initialize.setVisibility(View.GONE);
            requestPnr(databaseHandler.fetchUser().pnr_number);
            loader.setVisibility(View.VISIBLE);
        }
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        Button save = findViewById(R.id.save);
        View.OnClickListener onClickListenerSave = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText pnrInput = findViewById(R.id.pnrNumInput);

                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(pnrInput.getWindowToken(), 0);
                loader.setVisibility(View.VISIBLE);
                requestPnr(pnrInput.getText().toString());
            }
        };
        save.setOnClickListener(onClickListenerSave);

        final Button button_pnr = findViewById(R.id.button_pnr);
        final Button button_livetrain = findViewById(R.id.button_livetrain);
        final Button button_traindetails = findViewById(R.id.button_traindetails);

        View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                button_reset();
                button_state(v);
            }
        };
        button_pnr.setOnClickListener(onClickListener);
        button_livetrain.setOnClickListener(onClickListener);
        button_traindetails.setOnClickListener(onClickListener);

        final Button edit = findViewById(R.id.pnr_edit);

        View.OnClickListener editClickListner = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TableLayout pnrTable = findViewById(R.id.pnrTable);
                TableLayout liveTrainTable = findViewById(R.id.liveTrainTable);
                pnrTable.removeAllViews();
                liveTrainTable.removeAllViews();
                TextView pnrDetails = findViewById(R.id.pnrDetails);
                pnrDetails.setText("");
                TextView liveTrainDetails = findViewById(R.id.liveTrainPosition);
                pnrDetails.setText("");
                initialize.setVisibility(View.VISIBLE);
                databaseHandler.deleteUser();
            }
        };
        edit.setOnClickListener(editClickListner);
    }

    //REQUEST PNR DETAILS
    private void requestPnr(String pnrNumber){

        final String url = getString(R.string.url)+"pnr-status/?pnrnumber="+pnrNumber;
        String senderText = sender.getText().toString()+"\n"+url;
        sender.setText(senderText);
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.GET, url,
                null,new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {

                        pnrToDB(jsonObject);
                        try{

                            if(jsonObject.getString("response_code").equals("200"))
                            {

                                displayPnrStatus(jsonObject);
                                initialize.setVisibility(View.GONE);
                            }
                            else if(jsonObject.getString("response_code").equals("201"))
                            {

                                Context context = getApplicationContext();
                                String alert = "Invalid PNR Number:"+jsonObject.getString("response_code");

                                Toast.makeText(context, alert, Toast.LENGTH_LONG).show();
                            }
                            else
                            {

                                Context context = getApplicationContext();
                                String alert = "Server Problem:"+jsonObject.getString("response_code");

                                Toast.makeText(context, alert, Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException j){

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Context context = getApplicationContext();
                        String alert = "PNR Status Error:"+error+url;

                        Toast.makeText(context, alert, Toast.LENGTH_LONG).show();
                    }
                }
        );

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
    //DISPLAY PNR STATUS
    private void displayPnrStatus(JSONObject jsonObject){
        TextView pnr_numValue = findViewById(R.id.pnrNumValue);
        TextView pnrDetails = findViewById(R.id.pnrDetails);
        try{
            JSONArray passengerArray = jsonObject.getJSONArray("passengers");
            TableLayout tl = findViewById(R.id.pnrTable);

            String pnrDetailsString = "";
            pnrDetailsString = "Date of Journey: " + jsonObject.getString("doj") + "\n";
            pnrDetailsString += "Train Name: "+jsonObject.getJSONObject("train").getString("name")+"\n";
            pnrDetailsString += "Train Number: "+jsonObject.getJSONObject("train").getString("number")+"\n";
            pnrDetailsString += "Total Passengers: "+jsonObject.getString("total_passengers")+"\n";
            pnrDetailsString += "Boarding Point: "+jsonObject.getJSONObject("boarding_point").getString("name");
            pnrDetailsString += "("+jsonObject.getJSONObject("boarding_point").getString("code")+")\n";
            pnrDetailsString += "Reservation Upto: "+jsonObject.getJSONObject("reservation_upto").getString("name");
            pnrDetailsString += "("+jsonObject.getJSONObject("reservation_upto").getString("code")+")\n";

            pnrDetails.setText(pnrDetailsString);
            pnr_numValue.setText(jsonObject.getString("pnr"));


            TableRow rowh = new TableRow(this);
            TableRow.LayoutParams lph = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
            rowh.setLayoutParams(lph);
            LayoutInflater layoutInflaterh = getLayoutInflater();
            View rowhView = layoutInflaterh.inflate(R.layout.pnrhead,null);
            TextView passengerh = rowhView.findViewById(R.id.pnr_passengerHead);
            TextView currenth = rowhView.findViewById(R.id.pnr_currentHead);
            TextView bookingh = rowhView.findViewById(R.id.pnr_bookingHead);

            rowh.addView(rowhView);
            tl.addView(rowh);

            for(int i =0; i<passengerArray.length(); i++){
                TableRow row = new TableRow(this);
                TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
                row.setLayoutParams(lp);
                LayoutInflater layoutInflater = getLayoutInflater();
                View rowView = layoutInflater.inflate(R.layout.pnrtable,null);
                TextView passenger = rowView.findViewById(R.id.pnr_passenger);
                TextView current = rowView.findViewById(R.id.pnr_current);
                TextView booking = rowView.findViewById(R.id.pnr_booking);
                passenger.setText(passengerArray.getJSONObject(i).getString("no"));
                current.setText(passengerArray.getJSONObject(i).getString("current_status"));
                booking.setText(passengerArray.getJSONObject(i).getString("booking_status"));
                row.addView(rowView);
                tl.addView(row);
            }
        } catch(JSONException e){

            Context context = getApplicationContext();
            String alert = "PNR Status Error:"+e+jsonObject.toString();

            Toast.makeText(context, alert, Toast.LENGTH_LONG).show();
        }

    }
    //ADD PNR TO DATABASE
    private void pnrToDB(JSONObject jsonObject){
        try{
            JSONObject trainObject = jsonObject.getJSONObject("train");
            JSONObject boardingPointObject = jsonObject.getJSONObject("boarding_point");
            PnrDetails pnrDetails = new PnrDetails(jsonObject.getString("pnr"),trainObject.getString("number"),jsonObject.getString("doj"),boardingPointObject.getString("code"));
            databaseHandler.addUser(pnrDetails);
            trainDetails();
        } catch (JSONException e){

        }

    }
    //REQUEST TRAIN DETAILS
    private void trainDetails(){
        String url = getString(R.string.url)+"train-details/?trainnumbername="+databaseHandler.fetchUser().train_number;

        String senderText = sender.getText()+"\n"+url;
        sender.setText(senderText);
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.GET, url,
                null,new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        try {

                            JSONObject trainObject = jsonObject.getJSONObject("train");
                            JSONArray trainRouteArray = jsonObject.getJSONArray("route");

                            String boarding_point = databaseHandler.fetchUser().boarding_point;
                            String date = databaseHandler.fetchUser().date;
                            String start_date = findStartDay(trainRouteArray,boarding_point,date);

                            TrainDetails trainDetails = new TrainDetails(trainObject.getString("number"),trainObject.getString("name"),start_date);
                            databaseHandler.addTrain(trainDetails);
                            liveTrainRequest(databaseHandler.fetchUser().train_number,start_date);
                        } catch (JSONException e) {
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Context context = getApplicationContext();
                        String alert = "Train Details Error:"+error;

                        Toast.makeText(context, alert, Toast.LENGTH_SHORT).show();

                    }
                }
        );

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
    //FIND START DATE
    private String findStartDay(JSONArray jsonArray, String boarding_point,String date){
        String day = "";
        int dateDay, dateMonth, dateYear;
        dateDay = Integer.parseInt(date.split("-")[0]);
        dateMonth = Integer.parseInt(date.split("-")[1]);
        dateYear = Integer.parseInt(date.split("-")[2]);
        Calendar calendar = GregorianCalendar.getInstance();
        calendar.set(dateYear,dateMonth,dateDay);
        try{

            for (int i = 0; i<jsonArray.length(); i++){
                if(jsonArray.getJSONObject(i).getJSONObject("station").getString("code").equals(boarding_point)){
                    day = jsonArray.getJSONObject(i).getString("day");
                    i=jsonArray.length();
                }

            }

            int dayno = Integer.parseInt(day);
            --dayno;
            calendar.add(Calendar.DATE,dayno*(-1));
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-M-yyyy");

            return simpleDateFormat.format(calendar.getTime());
        } catch (JSONException e){
            return  "";
        }
    }
    //REQUEST LIVE TRAINlivetrainstatus/?trainnumber=08201&date=27-04-2018
    private void liveTrainRequest(String train_number,String start_date){
        String url = getString(R.string.url)+"livetrainstatus/?trainnumber="+train_number+"&date="+start_date;

        String senderText = sender.getText()+"\n"+url;
        sender.setText(senderText);
        JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.GET, url,
                null,new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                            displayLiveTrain(jsonObject);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Context context = getApplicationContext();
                        String alert = "Live Train Status Error:"+error;

                        Toast.makeText(context, alert, Toast.LENGTH_SHORT).show();

                    }
                }
        );

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
    //DISPLAY LIVE TRAIN POSITION
    private void displayLiveTrain(JSONObject jsonObject){
        try{

            JSONObject trainObject = jsonObject.getJSONObject("train");
            JSONArray routeArray = jsonObject.getJSONArray("route");

            TextView trainName = findViewById(R.id.liveTrainNameValue);
            TextView trainNo = findViewById(R.id.liveTrainNumValue);
            TextView trainPosition = findViewById(R.id.liveTrainPosition);

            TableLayout liveTrainTable = findViewById(R.id.liveTrainTable);

            trainName.setText(trainObject.getString("name"));
            trainNo.setText(trainObject.getString("number"));
            trainPosition.setText(jsonObject.getString("position"));

            TableRow rowh = new TableRow(this);
            TableRow.LayoutParams lph = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
            rowh.setLayoutParams(lph);
            LayoutInflater layoutInflaterh = getLayoutInflater();
            View rowhView = layoutInflaterh.inflate(R.layout.live_trainhead,null);
            TextView stationh = rowhView.findViewById(R.id.livetrain_stationHead);
            TextView scheduledh = rowhView.findViewById(R.id.livetrain_scheduledHead);
            TextView actualh = rowhView.findViewById(R.id.livetrain_actualHead);

            rowh.addView(rowhView);
            liveTrainTable.addView(rowh);

            for(int i =0; i<routeArray.length(); i++){
                TableRow row = new TableRow(this);
                TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
                row.setLayoutParams(lp);
                LayoutInflater layoutInflater = getLayoutInflater();
                View rowView = layoutInflater.inflate(R.layout.live_traintable,null);
                TextView station = rowView.findViewById(R.id.livetrain_station);
                TextView scheduled = rowView.findViewById(R.id.livetrain_scheduled);
                TextView actual = rowView.findViewById(R.id.livetrain_actual);
                Button has_arrived = rowView.findViewById(R.id.livetrain_hasArrivedStatus);
                Button has_departed = rowView.findViewById(R.id.livetrain_hasDepartedStatus);
                if(!routeArray.getJSONObject(i).getBoolean("has_departed")){
                    has_departed.setBackgroundColor(ContextCompat.getColor(this,R.color.colorAccent));
                }
                if(!routeArray.getJSONObject(i).getBoolean("has_arrived")){
                    has_arrived.setBackgroundColor(ContextCompat.getColor(this,R.color.colorAccent));
                }

                String stationStr = routeArray.getJSONObject(i).getJSONObject("station").getString("name")+"("+routeArray.getJSONObject(i).getJSONObject("station").getString("code")+")";
                station.setText(stationStr);
                scheduled.setText(routeArray.getJSONObject(i).getString("scharr"));
                actual.setText(routeArray.getJSONObject(i).getString("scharr"));
                row.addView(rowView);
                liveTrainTable.addView(row);
            }
            loader.setVisibility(View.GONE);

            Button refresh = findViewById(R.id.refresh);
            View.OnClickListener onClickListener = new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    refresh();
                }
            };
            refresh.setOnClickListener(onClickListener);
        } catch(JSONException e){

        }
    }
    private void refresh(){
        TableLayout pnrTable = findViewById(R.id.pnrTable);
        TableLayout liveTrainTable = findViewById(R.id.liveTrainTable);
        pnrTable.removeAllViews();
        liveTrainTable.removeAllViews();
        requestPnr(databaseHandler.fetchUser().pnr_number);
        loader.setVisibility(View.VISIBLE);
    }
    //Nav BUTTON RESET
    private void button_reset(){
        Button button_pnr = findViewById(R.id.button_pnr);
        Button button_livetrain = findViewById(R.id.button_livetrain);
        Button button_traindetails = findViewById(R.id.button_traindetails);

        button_pnr.setBackgroundColor(ContextCompat.getColor(this,R.color.colorPrimary));
        button_pnr.setTextColor(ContextCompat.getColor(this,R.color.colorWhite));
        button_livetrain.setBackgroundColor(ContextCompat.getColor(this,R.color.colorPrimary));
        button_livetrain.setTextColor(ContextCompat.getColor(this,R.color.colorWhite));
        button_traindetails.setBackgroundColor(ContextCompat.getColor(this,R.color.colorPrimary));
        button_traindetails.setTextColor(ContextCompat.getColor(this,R.color.colorWhite));
    }
    //CHANGE BUTTON STATE
    private void button_state(View selectedView){
        Button buttonToBeChanged = findViewById(selectedView.getId());
        buttonToBeChanged.setBackgroundColor(ContextCompat.getColor(this,R.color.colorWhite));
        buttonToBeChanged.setTextColor(ContextCompat.getColor(this,R.color.colorPrimary));

        String state = buttonToBeChanged.getText().toString();

        View pnr_status = findViewById(R.id.pnrStatusView);
        View live_train_status = findViewById(R.id.liveTrainStatusView);
        pnr_status.setVisibility(View.GONE);
        live_train_status.setVisibility(View.GONE);
        switch(state){
            case "PNR STATUS":
                pnr_status.setVisibility(View.VISIBLE);
                break;
            case "LIVE TRAIN STATUS":
                live_train_status.setVisibility(View.VISIBLE);
                break;
            case "TRAIN DETAILS":
                break;
        }
    }
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_pnr) {
            // Handle the camera action
        } else if (id == R.id.nav_live) {

        } else if (id == R.id.nav_train) {

        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
